=== Multi-Feature Plugin ===
Contributors: Your Name
Tags: WordPress, WooCommerce, Coupon, Product Search
Requires at least: 5.7
Tested up to: 6.0
Stable tag: 1.2
License: GPLv2 or later

== Description ==
A plugin that allows admins to search for products by title or SKU and change their statuses, and also includes a Smart Coupon Generator for WooCommerce.

== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/multi-feature-plugin/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Changelog ==
= 1.2 =
- Added product search functionality by title and SKU with status update options.
- Added Smart Coupon Generator for WooCommerce.

= 1.1 =
- Initial Release.
