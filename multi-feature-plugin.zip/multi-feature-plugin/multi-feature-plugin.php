<?php
/*
Plugin Name: Multi-Feature Plugin with Smart Coupon Generator and Product Search
Description: A plugin to manage multiple features including a Smart Coupon Code generator and a product search system with status update options.
Version: 1.3
Author: Your Name
*/

// Hook for admin menu
add_action('admin_menu', 'mfp_plugin_menu');

function mfp_plugin_menu() {
    add_menu_page('Multi Feature Plugin', 'Multi Features', 'manage_options', 'mfp-dashboard', 'mfp_dashboard_page');
    add_submenu_page('mfp-dashboard', 'Product Search', 'Product Search', 'manage_options', 'mfp-product-search', 'mfp_product_search_page');
    add_submenu_page('mfp-dashboard', 'Smart Coupon Generator', 'Smart Coupons', 'manage_options', 'mfp-smart-coupons', 'mfp_smart_coupon_page');
    add_submenu_page('mfp-dashboard', 'Plugin Manager', 'Plugin Manager', 'manage_options', 'mfp-plugin-manager', 'mfp_plugin_manager_page');
    add_submenu_page('mfp-dashboard', 'Export Posts/Pages', 'Export Posts/Pages', 'manage_options', 'mfp-export-posts-pages', 'mfp_export_posts_pages_page'); // Added export menu
}

// Dashboard Page (Main Page)
function mfp_dashboard_page() {
    echo '<h1>Welcome to the Multi Feature Plugin Dashboard</h1>';
    echo '<p>Choose a feature from the menu to get started!</p>';
}

// Export Posts/Pages by Title Page
function mfp_export_posts_pages_page() {
    ?>
    <h2>Export Posts/Pages by Title</h2>

    <form method="post">
        <label for="mfp_post_page_title">Enter Post/Page Title or Keyword:</label>
        <input type="text" name="mfp_post_page_title" id="mfp_post_page_title" placeholder="Enter title or keyword">
        <input type="submit" name="mfp_export_posts_pages" value="Export Posts/Pages">
    </form>

    <?php
    // Check if the export button is pressed
    if (isset($_POST['mfp_export_posts_pages'])) {
        $search_query = sanitize_text_field($_POST['mfp_post_page_title']);
        mfp_export_posts_pages_by_title($search_query);
    }
}

// Function to export posts/pages by title to CSV
function mfp_export_posts_pages_by_title($search_query) {
    // Query posts and pages by title or keyword
    $args = array(
        'post_type'      => array('post', 'page'),
        'posts_per_page' => -1, // Get all posts and pages
        's'               => $search_query, // Search by title or keyword
    );

    $query = new WP_Query($args);

    if ($query->have_posts()) {
        // Prepare CSV content
        $csv_output = "Post/Page Title,Post Type,Post Date,Status,Post URL\n";

        while ($query->have_posts()) {
            $query->the_post();
            $post_title = get_the_title();
            $post_type = get_post_type();
            $post_date = get_the_date();
            $status = get_post_status();
            $post_url = get_permalink();

            // Append to CSV
            $csv_output .= '"' . $post_title . '","' . $post_type . '","' . $post_date . '","' . $status . '","' . $post_url . "\"\n";
        }

        wp_reset_postdata();

        // Send headers for CSV download
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment;filename=posts-pages-export.csv');

        // Output the CSV content
        echo $csv_output;
        exit;
    } else {
        echo '<p>No posts/pages found matching your search.</p>';
    }
}

// Product Search Page
function mfp_product_search_page() {
    ?>
    <h2>Search Products</h2>
    <form method="post">
        <label for="mfp_product_search">Search by Title or SKU:</label>
        <input type="text" name="mfp_product_search" id="mfp_product_search" placeholder="Enter product title or SKU">
        <input type="submit" name="mfp_search_products" value="Search Products">
    </form>
    <?php
    if (isset($_POST['mfp_search_products'])) {
        $search_query = sanitize_text_field($_POST['mfp_product_search']);
        mfp_search_and_display_products($search_query);
    }
}

// Function to search and display products
function mfp_search_and_display_products($search_query) {
    // Query products by title or SKU
    $args = array(
        'post_type'      => 'product',
        'posts_per_page' => -1, // Get all products
        's'               => $search_query, // Search by title or SKU
    );

    $query = new WP_Query($args);

    if ($query->have_posts()) {
        echo '<h3>Search Results:</h3>';
        echo '<table><thead><tr><th>Product Title</th><th>SKU</th><th>Status</th><th>Change Status</th></tr></thead><tbody>';

        while ($query->have_posts()) {
            $query->the_post();
            $product = wc_get_product(get_the_ID());
            $sku = $product->get_sku();
            $status = get_post_status(get_the_ID());

            echo '<tr>';
            echo '<td>' . get_the_title() . '</td>';
            echo '<td>' . ($sku ? $sku : 'No SKU') . '</td>';
            echo '<td>' . ucfirst($status) . '</td>';
            echo '<td>';
            echo '<form method="post" style="display:inline-block;">
                    <input type="hidden" name="mfp_product_id" value="' . get_the_ID() . '">
                    <select name="mfp_product_status">
                        <option value="publish" ' . selected($status, 'publish', false) . '>Published</option>
                        <option value="draft" ' . selected($status, 'draft', false) . '>Draft</option>
                        <option value="pending" ' . selected($status, 'pending', false) . '>Pending</option>
                    </select>
                    <input type="submit" name="mfp_update_product_status" value="Update">
                </form>';
            echo '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
        wp_reset_postdata();
    } else {
        echo '<p>No products found matching your search.</p>';
    }
}

// Handle product status update
if (isset($_POST['mfp_update_product_status']) && isset($_POST['mfp_product_id'])) {
    $product_id = intval($_POST['mfp_product_id']);
    $new_status = sanitize_text_field($_POST['mfp_product_status']);

    // Update product status
    $product = array(
        'ID'          => $product_id,
        'post_status' => $new_status,
    );

    wp_update_post($product);
    echo '<div class="updated"><p>Product status updated successfully.</p></div>';
}

// Smart Coupon Code Page
function mfp_smart_coupon_page() {
    if (isset($_POST['mfp_create_coupon'])) {
        // Process form submission and create the coupon
        mfp_create_coupon($_POST);
    }
    ?>
    <h2>Create Smart Coupon Code</h2>
    <form method="post">
        <h3>General</h3>
        <label for="mfp_coupon_code">Coupon Code:</label>
        <input type="text" name="mfp_coupon_code" id="mfp_coupon_code" required><br><br>

        <label for="mfp_discount_type">Discount Type:</label>
        <select name="mfp_discount_type" id="mfp_discount_type">
            <option value="fixed_cart">Fixed Cart Discount</option>
            <option value="percent">Percentage Discount</option>
            <option value="fixed_product">Fixed Product Discount</option>
        </select><br><br>

        <label for="mfp_coupon_amount">Coupon Amount:</label>
        <input type="number" name="mfp_coupon_amount" id="mfp_coupon_amount" step="0.01" min="0" value="0" required><br><br>

        <label for="mfp_free_shipping">Allow Free Shipping:</label>
        <input type="checkbox" name="mfp_free_shipping" id="mfp_free_shipping"><br><br>

        <label for="mfp_expiry_date">Coupon Expiry Date:</label>
        <input type="date" name="mfp_expiry_date" id="mfp_expiry_date"><br><br>

        <h3>Usage Restrictions</h3>
        <label for="mfp_minimum_spend">Minimum Spend:</label>
        <input type="number" name="mfp_minimum_spend" id="mfp_minimum_spend" step="0.01" min="0"><br><br>

        <label for="mfp_maximum_spend">Maximum Spend:</label>
        <input type="number" name="mfp_maximum_spend" id="mfp_maximum_spend" step="0.01" min="0"><br><br>

        <label for="mfp_individual_use">Individual Use Only:</label>
        <input type="checkbox" name="mfp_individual_use" id="mfp_individual_use"><br><br>

        <label for="mfp_exclude_sale_items">Exclude Sale Items:</label>
        <input type="checkbox" name="mfp_exclude_sale_items" id="mfp_exclude_sale_items"><br><br>

        <h3>Usage Limits</h3>
        <label for="mfp_usage_limit">Usage Limit per Coupon:</label>
        <input type="number" name="mfp_usage_limit" id="mfp_usage_limit" min="1" value="1"><br><br>

        <label for="mfp_usage_limit_per_user">Usage Limit per User:</label>
        <input type="number" name="mfp_usage_limit_per_user" id="mfp_usage_limit_per_user" min="1" value="1"><br><br>

        <h3>Product Restrictions</h3>
        <label for="mfp_products">Products:</label>
        <input type="text" name="mfp_products" id="mfp_products" placeholder="Enter product IDs, comma-separated"><br><br>

        <label for="mfp_exclude_products">Exclude Products:</label>
        <input type="text" name="mfp_exclude_products" id="mfp_exclude_products" placeholder="Enter product IDs, comma-separated"><br><br>

        <label for="mfp_product_categories">Product Categories:</label>
        <input type="text" name="mfp_product_categories" id="mfp_product_categories" placeholder="Enter category IDs, comma-separated"><br><br>

        <label for="mfp_exclude_categories">Exclude Categories:</label>
        <input type="text" name="mfp_exclude_categories" id="mfp_exclude_categories" placeholder="Enter category IDs, comma-separated"><br><br>

        <label for="mfp_allowed_emails">Allowed Emails:</label>
        <input type="text" name="mfp_allowed_emails" id="mfp_allowed_emails" placeholder="Enter emails, comma-separated"><br><br>

        <input type="submit" name="mfp_create_coupon" value="Create Coupon">
    </form>
    <?php
}

// Create Coupon Functionality
function mfp_create_coupon($data) {
    $coupon_code = sanitize_text_field($data['mfp_coupon_code']);
    $discount_type = sanitize_text_field($data['mfp_discount_type']);
    $coupon_amount = sanitize_text_field($data['mfp_coupon_amount']);
    $expiry_date = isset($data['mfp_expiry_date']) ? sanitize_text_field($data['mfp_expiry_date']) : '';
    $free_shipping = isset($data['mfp_free_shipping']) ? 'yes' : 'no';
    $minimum_spend = isset($data['mfp_minimum_spend']) ? sanitize_text_field($data['mfp_minimum_spend']) : '';
    $maximum_spend = isset($data['mfp_maximum_spend']) ? sanitize_text_field($data['mfp_maximum_spend']) : '';
    $individual_use = isset($data['mfp_individual_use']) ? 'yes' : 'no';
    $exclude_sale_items = isset($data['mfp_exclude_sale_items']) ? 'yes' : 'no';
    $usage_limit = isset($data['mfp_usage_limit']) ? sanitize_text_field($data['mfp_usage_limit']) : '';
    $usage_limit_per_user = isset($data['mfp_usage_limit_per_user']) ? sanitize_text_field($data['mfp_usage_limit_per_user']) : '';
    $products = isset($data['mfp_products']) ? sanitize_text_field($data['mfp_products']) : '';
    $exclude_products = isset($data['mfp_exclude_products']) ? sanitize_text_field($data['mfp_exclude_products']) : '';
    $product_categories = isset($data['mfp_product_categories']) ? sanitize_text_field($data['mfp_product_categories']) : '';
    $exclude_categories = isset($data['mfp_exclude_categories']) ? sanitize_text_field($data['mfp_exclude_categories']) : '';
    $allowed_emails = isset($data['mfp_allowed_emails']) ? sanitize_text_field($data['mfp_allowed_emails']) : '';

    // Create Coupon Object
    $coupon = array(
        'post_title'    => $coupon_code,
        'post_status'   => 'publish',
        'post_type'     => 'shop_coupon',
    );

    $coupon_id = wp_insert_post($coupon);

    // Set coupon meta data
    update_post_meta($coupon_id, 'discount_type', $discount_type);
    update_post_meta($coupon_id, 'coupon_amount', $coupon_amount);
    update_post_meta($coupon_id, 'expiry_date', $expiry_date);
    update_post_meta($coupon_id, 'free_shipping', $free_shipping);
    update_post_meta($coupon_id, 'minimum_amount', $minimum_spend);
    update_post_meta($coupon_id, 'maximum_amount', $maximum_spend);
    update_post_meta($coupon_id, 'individual_use', $individual_use);
    update_post_meta($coupon_id, 'exclude_sale_items', $exclude_sale_items);
    update_post_meta($coupon_id, 'usage_limit', $usage_limit);
    update_post_meta($coupon_id, 'usage_limit_per_user', $usage_limit_per_user);
    update_post_meta($coupon_id, 'product_ids', $products);
    update_post_meta($coupon_id, 'exclude_product_ids', $exclude_products);
    update_post_meta($coupon_id, 'product_categories', $product_categories);
    update_post_meta($coupon_id, 'exclude_product_categories', $exclude_categories);
    update_post_meta($coupon_id, 'allowed_emails', $allowed_emails);
}

// Plugin Manager Page
function mfp_plugin_manager_page() {
    ?>
    <h2>Plugin Manager</h2>
    <p>Manage the activation and deactivation of your plugins.</p>

    <?php
    // Get all installed plugins
    $all_plugins = get_plugins();
    
    if (!empty($all_plugins)) {
        echo '<table class="widefat striped">
                <thead><tr><th>Plugin Name</th><th>Status</th><th>Action</th></tr></thead><tbody>';
        
        foreach ($all_plugins as $plugin_path => $plugin) {
            $plugin_name = $plugin['Name'];
            $plugin_slug = basename($plugin_path, '.php');
            $is_active = is_plugin_active($plugin_path);
            
            echo '<tr>
                    <td>' . esc_html($plugin_name) . '</td>
                    <td>' . ($is_active ? 'Active' : 'Inactive') . '</td>
                    <td>';
            
            // If active, show deactivate button, else show activate button
            if ($is_active) {
                echo '<a href="' . wp_nonce_url(admin_url('plugins.php?action=deactivate&plugin=' . $plugin_path), 'deactivate-plugin_' . $plugin_path) . '" class="button">Deactivate</a>';
            } else {
                echo '<a href="' . wp_nonce_url(admin_url('plugins.php?action=activate&plugin=' . $plugin_path), 'activate-plugin_' . $plugin_path) . '" class="button">Activate</a>';
            }
            
            echo '</td></tr>';
        }
        
        echo '</tbody></table>';
    } else {
        echo '<p>No plugins found.</p>';
    }
}
?>
